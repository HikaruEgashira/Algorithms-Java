////////////////////////////////////////////////////////////////////////////////
// A Java program to find data with Binary Search                  <Name> <Date>
////////////////////////////////////////////////////////////////////////////////
import java.util.Objects;

public class BinarySearch {
  // Find d from A
  static boolean binary_search(int[] A, int d, int n) {
    int l = 0;
    int h = n - 1;
    while (l < h) {
      int m = (l + h) / 2;
      if (A[m] == d) return true;  // Data d exists

      if (d < A[m]) h = m - 1;
      else          l = m + 1;
    }
    if (A[l] == d) return true;    // Data d exists
    else           return false;   // Data d does not exist
  }


  public static void main(String[] args) {
    // Process arguments
    if (args.length < 2 || args.length >= 4) {
      System.err.println("Usage: java BinarySearch <numdata> <target data> <option (v)>");
      System.exit(1);
    }
    int n = Integer.parseInt(args[0]);
    int d = Integer.parseInt(args[1]);

    int[] A = new int[n];
    
    // Array initialized
    for (int i = 0; i < n; i++) A[i] = i + 1;

    // Find data 
    boolean rslt = binary_search(A, d, n);

    // Show result
    if (rslt == true) System.out.println("Data found: " + d);
    else              System.out.println("Sorry. Data not found: " + d);

    // Show array contents if v option is set
    if (args.length == 3) {
      if (Objects.equals(args[2], "v")) {
        for (int i = 0; i < n; i++) System.out.print(A[i] + " ");
        System.out.println();
      } else {
        System.err.println("Invalid option: " + args[2]);
        System.exit(1);
      }
    }
    
  }
}
