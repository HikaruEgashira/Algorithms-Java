////////////////////////////////////////////////////////////////////////////////
// A Java program to find data with Linear Search                  <Name> <Date>
////////////////////////////////////////////////////////////////////////////////
import java.util.Objects;

public class LinearSearch {
  // Find d from A
  static boolean linear_search(int[] A, int d, int n) {
    for (int i = 0; i < n; i++) {
      if (A[i] == d) return true;  // Data d exists
    }
    return false;  // Data d does not exist
  }


  public static void main(String[] args) {
    // Process arguments
    if (args.length < 2 || args.length >= 4) {
      System.err.println("Usage: java LinearSearch <numdata> <target data> <option (v)>");
      System.exit(1);
    }
    int n = Integer.parseInt(args[0]);
    int d = Integer.parseInt(args[1]);

    int[] A = new int[n];
    
    // Array initialized
    for (int i = 0; i < n; i++) A[i] = i + 1;

    // Find data 
    boolean rslt = linear_search(A, d, n);

    // Show result
    if (rslt == true) System.out.println("Data found: " + d);
    else              System.out.println("Sorry. Data not found: " + d);

    // Show array contents if v option is set
    if (args.length == 3) {
      if (Objects.equals(args[2], "v")) {
        for (int i = 0; i < n; i++) System.out.print(A[i] + " ");
        System.out.println();
      } else {
        System.err.println("Invalid option: " + args[2]);
        System.exit(1);
      }
    }
    
  }
}
